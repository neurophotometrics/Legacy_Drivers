#include "NPM_LCD.h"
#include "Arduino.h"

NPM_LCD::NPM_LCD(uint8_t lcd_Addr,uint8_t lcd_cols,uint8_t lcd_rows)
{
  _Addr = lcd_Addr;
  _cols = lcd_cols;
  _rows = lcd_rows;
}

void NPM_LCD::print(String x){
  char buffer[32];
  x.toCharArray(buffer,32);
  Wire.beginTransmission(_Addr);
  Wire.write(buffer);
  Wire.endTransmission();
}

void NPM_LCD::init(){
  init_priv();
  set_contrast(35);
  clear();
}

void NPM_LCD::init_priv(){
  Wire.begin();
  TWBR = 152;
}

void NPM_LCD::set_cursor(uint8_t col, uint8_t row){
  int row_offsets[] = { 0x00, 0x40, 0x14, 0x54 };
  command2(SET_CURSOR,col+row_offsets[row]);
}


void NPM_LCD::command1(uint8_t val){
  Wire.beginTransmission(_Addr);
  Wire.write(PREFIX);
  Wire.write(val);
  Wire.endTransmission();
}

void NPM_LCD::command2(uint8_t val, uint8_t param){
  Wire.beginTransmission(_Addr);
  Wire.write(PREFIX);
  Wire.write(val);
  Wire.write(param);
  Wire.endTransmission();
}

void NPM_LCD::set_contrast(uint8_t val){
  val = min(max(1,val),50);
  command2(SET_CONTRAST,val);
}

void NPM_LCD::clear(){
  command1(CLEAR_DISPLAY);
  delay(2);
}