#ifndef NPM_LCD_h
#define NPM_LCD_h

#include <Wire.h>
#include "Arduino.h"

//commands
#define PREFIX 0xFE
#define CLEAR_DISPLAY 0x51
#define DISPLAY_ON 0x41
#define DISPLAY_OFF 0x42
#define SET_CURSOR 0x45
#define CURSOR_HOME 0x46
#define SHIFT_LEFT 0x49
#define SHIFT_RIGHT 0x4A
#define SET_CONTRAST 0x52


class NPM_LCD {
  public:
    NPM_LCD(uint8_t,uint8_t,uint8_t);
    void clear();
    void set_cursor(uint8_t, uint8_t);
    void set_contrast(uint8_t);
    void command1(uint8_t);
    void command2(uint8_t,uint8_t);
    void print(String);
    void init();
  
  private:
    void init_priv();
    uint8_t _Addr;
    uint8_t _cols;
    uint8_t _rows;

};

#endif